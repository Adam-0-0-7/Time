﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Time_and_Money.Models
{
    public class User
    {
        // Fields
        string email;
        string password;
        // Contructors
        // Methods
    }
}
