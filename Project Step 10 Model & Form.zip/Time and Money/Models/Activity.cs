﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Time_and_Money.Models
{
    public class Activity : User
    {
        string category;
        string activity;
        DateTime dt1 = new DateTime();
    }
}
