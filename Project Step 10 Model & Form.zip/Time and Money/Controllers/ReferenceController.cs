﻿using Microsoft.AspNetCore.Mvc;

namespace Time_and_Money.Controllers
{
    public class ReferenceController : Controller
    {
    }
}
