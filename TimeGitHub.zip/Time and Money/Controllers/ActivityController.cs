﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Time_and_Money.Models;

namespace Time_and_Money.Controllers
{
    public class ActivityController : Controller
    {
        //   F i e l d s   &   P r o p e r t i e s

        private IActivityRepository _repository;

        //   C o n s t r u c t o r s

        public ActivityController(IActivityRepository repository)
        {
            _repository = repository;
        }

        //   M e t h o d s

        //   C r e a t e

        [HttpGet]
        public IActionResult Create()
        {
            return View(new Activity { });
        }

        [HttpPost]
        public IActionResult Create(Activity a)
        {
            return View(a);
        }

        //   R e a d
        [HttpGet]
        public IActionResult Detail()
        {
            return View(_repository.GetAllActivities().OrderBy(a => a.Date));
        }
        [HttpPost]
        public IActionResult Detail(int id)
        {
            Activity a = _repository.GetActivityById(id);
            if (a == null)
            {
                return RedirectToAction("Detail");
            }
            return View(a);
        }

        //   U p d a t e

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Activity a = _repository.GetActivityById(id);
            if (a == null)
            {
                return RedirectToAction("Index");
            }
            return View(a);
        }

        [HttpPost]
        public IActionResult Edit(Activity a)
        {
            return View(a);
        }

        //   D e l e t e

        [HttpGet]
        public IActionResult Delete(int id)
        {
            Activity a = _repository.GetActivityById(id);
            if (a == null)
            {
                return RedirectToAction("Index");
            }
            return View(a);
        }

        [HttpPost]
        public IActionResult Delete(Activity a)
        {
            _repository.Delete(a.ActivityId);
            return RedirectToAction("Index");
        }
    }
}
