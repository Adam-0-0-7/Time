﻿using Microsoft.AspNetCore.Mvc;
using Time_and_Money.Models;

namespace Time_and_Money.Controllers
{
    public class UserController : Controller
    {
        //   F i e l d s   &   P r o p e r t i e s

        private IUserRepository _repository;

        //   C o n s t r u c t o r s

        public UserController(IUserRepository repository)
        {
            _repository = repository;
        }

        //   M e t h o d s

        //   C r e a t e

        [HttpGet]
        public IActionResult NewUser()
        {
            return View();
        }

        [HttpPost]
        public IActionResult NewUser(User u)
        {
            if (ModelState.IsValid)
            {
                User newUser = _repository.Create(u);
                if (newUser == null)
                {
                    ModelState.AddModelError("", "This User Already Exists.");
                    return View(u);
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }

            return View(u);
        }
        //   R e a d

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(User u)
        {
            return View(u);
        }

        public IActionResult Logout()
        {
            return RedirectToAction("Index", "Home");
        }
        //   U p d a t e

        [HttpGet]
        public IActionResult ResetPassword()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ResetPassword(User u)
        {
            return View(u);
        }
    }
}
