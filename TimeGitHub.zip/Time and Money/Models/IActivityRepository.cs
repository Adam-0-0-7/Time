﻿using System.Linq;

namespace Time_and_Money.Models
{
    public interface IActivityRepository
    {
        // CREATE

        public Activity Create(Activity activity);

        // READ

        public IQueryable<Activity> GetAllActivities();
        public Activity GetActivityById(int id);

        // UPDATE

        public Activity Update(Activity name);

        // DELETE

        public bool Delete(int id);
    }
}
