﻿using System;

namespace Time_and_Money.Models
{
    public class Activity
    {
        public int      ActivityId    { get; set; }
        public bool     Sleep         { get; set; }
        public bool     School        { get; set; }
        public bool     Work          { get; set; }
        public bool     Eat           { get; set; }
        public bool     OtherActivity { get; set; }
        public double   Hours         { get; set; }
        public DateTime Date          { get; set; } 
    }
}
