﻿using System;
using System.Linq;

namespace Time_and_Money.Models
{
    public class EfActivityRepository : IActivityRepository
    {
        // FIELDS & PROPERTIES

        private AppDbContext    _context;
        private IUserRepository _userRepository;

        // CONSTRUCTORS

        public EfActivityRepository(AppDbContext context, IUserRepository userRepository)
        {
            _context = context;
            _userRepository = userRepository;
        }

        // METHODS

        // CREATE

        public Activity Create(Activity activity)
        {
            _context.Activities.Add(activity);
            _context.SaveChanges();
            return activity;
        }

        // READ

        public IQueryable<Activity> GetAllActivities()
        {
            return _context.Activities;
        }

        public Activity GetActivityById(int id)
        {
            return _context.Activities.Find(id);
        }

        // UPDATE

        public Activity Update(Activity activity)
        {
            Activity activityToUpdate = GetActivityById(activity.ActivityId);
            if (activityToUpdate != null)
            {
                activityToUpdate.Sleep = activity.Sleep;
                activityToUpdate.School = activity.School;
                activityToUpdate.Work = activity.Work;
                activityToUpdate.Eat = activity.Eat;
                activityToUpdate.OtherActivity = activity.OtherActivity;
                activityToUpdate.Hours = activity.Hours;
                activityToUpdate.Date = activity.Date;
            }
            return activityToUpdate;
        }


        // DELETE

        public bool Delete(int id)
        {
            Activity activityToDelete = GetActivityById(id);
            if(activityToDelete == null)
            {
                return false;
            }
            try
            {
                _context.Activities.Remove(activityToDelete);
                _context.SaveChanges();
            }
            catch (Exception e)
            {

            }
            return false;
        }

    }
}
