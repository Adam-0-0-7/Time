﻿using System.Linq;

namespace Time_and_Money.Models
{
    public interface IUserRepository
    {
        // CREATE

        public User Create(User user);

        // READ

        public IQueryable<User> GetAllUsers();
        public User GetUserByEmailAddress(string emailAddress);
        public User GetUserById(int id);

        // UPDATE
        public User Update(User user);

        // DELETE

        public bool Delete(int id);
        public bool Delete(User user);

    }
}
