﻿using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Time_and_Money.Models
{
    public class EfUserRepository : IUserRepository
    {
        // Fields & Properties

        private AppDbContext _context;
        private ISession     _session;

        // Constructors

        public EfUserRepository(AppDbContext context, IHttpContextAccessor httpContext)
        {
            _context = context;
            _session = httpContext.HttpContext.Session;
        }

        // Methods

        // Create

        public User Create(User u)
        {
            _context.Users.Add(u);
            _context.SaveChanges();
            return u;
        }

        // Read

        public IQueryable<User> GetAllUsers()
        {
            return _context.Users;
        }

        public User GetUserByEmailAddress(string emailAddress)
        {
            return _context.Users.FirstOrDefault(u => u.Email == emailAddress);
        }
        public User GetUserById(int id)
        {
            return _context.Users.FirstOrDefault(u => u.UserId == id);
        }

        // Update

        public User Update(User u)
        {
            User userToUpdate = GetUserById(u.UserId);
            if (userToUpdate != null)
            {
                userToUpdate.Password = u.Password;
                _context.SaveChanges();
            }
            return userToUpdate;
        }


        // Delete

        public bool Delete(int id)
        {
            User userToDelete = GetUserById(id);
            if (userToDelete == null)
            {
                return false;
            }
            _context.Users.Remove(userToDelete);
            _context.SaveChanges();
            return true;

        }
        public bool Delete(User u)
        {
            return Delete(u.UserId);
        }

    }
}
