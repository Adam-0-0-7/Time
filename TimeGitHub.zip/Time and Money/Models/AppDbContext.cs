﻿using Microsoft.EntityFrameworkCore;

namespace Time_and_Money.Models
{
    public class AppDbContext : DbContext
    {
        // FIELDS & PROPERTIES

        public DbSet<User>     Users      { get; set; }
        public DbSet<Activity> Activities { get; set; }

        // CONSTRUCTORS

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // METHODS

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Users

            modelBuilder.Entity<User>().HasIndex(u => u.UserId).IsUnique();

            // Activities

            modelBuilder.Entity<Activity>().HasData(new Activity
               {
                   ActivityId = 1,
                   Sleep = true,
                   Hours = 6.5,
                   Date = new System.DateTime(2021, 05, 10)
               });
        }
    }
}
