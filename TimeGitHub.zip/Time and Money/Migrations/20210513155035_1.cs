﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Time_and_Money.Migrations
{
    public partial class _1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Activities",
                columns: table => new
                {
                    ActivityId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Sleep = table.Column<bool>(type: "bit", nullable: false),
                    School = table.Column<bool>(type: "bit", nullable: false),
                    Work = table.Column<bool>(type: "bit", nullable: false),
                    Eat = table.Column<bool>(type: "bit", nullable: false),
                    OtherActivity = table.Column<bool>(type: "bit", nullable: false),
                    Hours = table.Column<double>(type: "float", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Activities", x => x.ActivityId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserId);
                });

            migrationBuilder.InsertData(
                table: "Activities",
                columns: new[] { "ActivityId", "Date", "Eat", "Hours", "OtherActivity", "School", "Sleep", "Work" },
                values: new object[] { 1, new DateTime(2021, 5, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), false, 6.5, false, false, true, false });

            migrationBuilder.CreateIndex(
                name: "IX_Users_UserId",
                table: "Users",
                column: "UserId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Activities");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
