﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Time_and_Money.Migrations
{
    public partial class firstLocal : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
